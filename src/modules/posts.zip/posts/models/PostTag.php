<?php

/**
 * Class PostTag
 */
class PostTag extends Dot\Model
{

    /**
     * @var string
     */
    protected $table = "post_tags";

}
