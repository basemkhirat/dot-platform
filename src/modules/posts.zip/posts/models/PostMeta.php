<?php

/**
 * Class PostMeta
 */
class PostMeta extends Dot\Model{

    /**
     * @var string
     */
    protected $table = "posts_meta";

    /**
     * @var bool
     */
    public $timestamps = false;

}
