<?php

/**
 * Trait Optimizable
 */
trait Optimizable
{

}

