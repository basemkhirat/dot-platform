<?php

return [

    "formats" => [
        "post" => "fa-newspaper-o",
        "article" => "fa-newspaper-o",
        "video" => "fa-video-camera",
        "album" => "fa-camera",
        "event" => "fa-calendar-o"
    ]

];